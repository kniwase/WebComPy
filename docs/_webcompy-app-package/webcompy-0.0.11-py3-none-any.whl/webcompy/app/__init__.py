from webcompy.app._app import WebComPyApp

__all__ = [
    "WebComPyApp",
]
