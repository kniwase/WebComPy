from webcompy._browser._modules import browser

__all__ = [
    "browser",
]
